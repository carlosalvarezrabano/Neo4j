package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class PokemonsCazaBichos implements Action{

    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Pokemons del entrenador Caza Bichos: \n" + pokemonDb.pokemonsCaza_Bichos());
    }
}

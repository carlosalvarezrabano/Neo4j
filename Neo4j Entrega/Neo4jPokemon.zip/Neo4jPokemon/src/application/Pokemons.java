package application;

import java.io.File;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;

import org.neo4j.helpers.collection.Iterators;

import conf.Conf;

public class Pokemons {

    private static final File DB_PATH = new File(Conf.getInstance().getProperty("DB_PATH"));
    
    private static GraphDatabaseService db;
    //Consultas Elementales
    private static String NoSQL_TIPOS_GANAN_PLANTA = Conf.getInstance().getProperty("NoSQL_TIPOS_GANAN_PLANTA");
    private static String NoSQL_POKEMONS_CAZA_BICHOS = Conf.getInstance().getProperty("NoSQL_POKEMONS_CAZA_BICHOS");
    private static String NoSQL_POKEMONS_TIPO_AGUA = Conf.getInstance().getProperty("NoSQL_POKEMONS_TIPO_AGUA");
    private static String NoSQL_NUMERO_TIPOS_POKEMON = Conf.getInstance().getProperty("NoSQL_NUMERO_TIPOS_POKEMON");
    //Consultas Intermedias
    private static String NoSQL_POKEMONS_NUMERO_MAYOR_20 = Conf.getInstance().getProperty("NoSQL_POKEMONS_NUMERO_MAYOR_20");
    private static String NoSQL_POKEMONS_NUMERO_MATOR_10_MAS_1_TIPOS = Conf.getInstance().getProperty("NoSQL_POKEMONS_NUMERO_MATOR_10_MAS_1_TIPOS");
    private static String NoSQL_POKEMONS_EVOLUCIONAN = Conf.getInstance().getProperty("NoSQL_POKEMONS_EVOLUCIONAN");
    private static String NoSQL_POKEMONS_AGRUPADOS_POR_TIPO = Conf.getInstance().getProperty("NoSQL_POKEMONS_AGRUPADOS_POR_TIPO");
    //Consultas Avanzadas
    private static String NoSQL_TIPOS_POKEMON_ASH = Conf.getInstance().getProperty("NoSQL_TIPOS_POKEMON_ASH");
    private static String NoSQL_CAMINO_MAS_CORTO_ASH_BULBASUR = Conf.getInstance().getProperty("NoSQL_CAMINO_MAS_CORTO_ASH_BULBASUR");
    

    
    public Pokemons() {
	GraphDatabaseFactory graphDbFactory = new GraphDatabaseFactory();
	db = graphDbFactory.newEmbeddedDatabase(DB_PATH);
    }

    public String tiposGananPlanta() {
	String output = "";

	try (Transaction tx = db.beginTx();
		Result result = db.execute(NoSQL_TIPOS_GANAN_PLANTA)) {
	    Iterator<Node> columns = result.columnAs("tipos");
	    for (Node node : Iterators.asIterable(columns)) {
		output += node.getProperty("nombre") + " ";
	    }

	} finally {
	    shutdown();
	}
	return output;
    }

    public String pokemonsCaza_Bichos() {
	String rows = "";

	try (Transaction tx = db.beginTx();
		Result result = db.execute(NoSQL_POKEMONS_CAZA_BICHOS)) {
	    while (result.hasNext()) {
		Map<String, Object> row = result.next();
		for (Entry<String, Object> column : row.entrySet()) {
		    rows += column.getValue() + " ";
		}
	    }

	} finally {
	    shutdown();
	}
	return rows;
    }

    public String pokemonsMayor20() {
	String rows = "";
	boolean salto = false;

	try (Transaction tx = db.beginTx();
		Result result = db.execute(NoSQL_POKEMONS_NUMERO_MAYOR_20)) {
	    while (result.hasNext()) {
		Map<String, Object> row = result.next();
		for (Entry<String, Object> column : row.entrySet()) {
		    rows += column.getValue();
		    if (salto) {
			rows += "\n";
			salto = false;
		    } else {
			rows += "\t\t\t";
			salto = true;
		    }
		}
	    }

	} finally {
	    shutdown();
	}
	return rows;
    }

    public String pokemonsMayor10Mas1Tipos() {
	String rows = "";
	int countFields = 1;

	try (Transaction tx = db.beginTx();
		Result result = db.execute(
			NoSQL_POKEMONS_NUMERO_MATOR_10_MAS_1_TIPOS)) {
	    while (result.hasNext()) {
		Map<String, Object> row = result.next();
		for (Entry<String, Object> column : row.entrySet()) {
		    switch (countFields) {
		    case 1:
			rows += "Numero: " + column.getValue();
			countFields++;
			break;
		    case 2:
			rows += " ---> Nombre: " + column.getValue();
			countFields++;
			break;
		    case 3:
			rows += " ---> Numero de tipos: " + column.getValue()
				+ "\n";
			countFields = 1;
			break;
		    }
		}
	    }

	} finally {
	    shutdown();
	}
	return rows;
    }

    public String tiposPokemonAsh() {
	String output = "";

	try (Transaction tx = db.beginTx();
		Result result = db.execute(NoSQL_TIPOS_POKEMON_ASH)) {
	    Iterator<Node> columns = result.columnAs("Tipos_Pokemon_Ash");
	    for (Node node : Iterators.asIterable(columns)) {
		output += node.getProperty("nombre") + " ";
	    }

	} finally {
	    shutdown();
	}
	return output;
    }

    public String pokemonsEvolucionan() {
	String rows = "";
	boolean evo = true;

	try (Transaction tx = db.beginTx();
		Result result = db.execute(NoSQL_POKEMONS_EVOLUCIONAN)) {
	    while (result.hasNext()) {
		Map<String, Object> row = result.next();
		for (Entry<String, Object> column : row.entrySet()) {
		    rows += column.getValue();
		    if (evo) {
			rows += " evoluciona a ";
			evo = false;
		    } else {
			rows += "\n";
			evo = true;
		    }
		}
	    }

	} finally {
	    shutdown();
	}
	return rows;
    }

    public String caminoMasCortoAshBulbasur() {
	String rows = "";

	try (Transaction tx = db.beginTx();
		Result result = db
			.execute(NoSQL_CAMINO_MAS_CORTO_ASH_BULBASUR)) {
	    while (result.hasNext()) {
		Map<String, Object> row = result.next();
		for (Entry<String, Object> column : row.entrySet()) {
		    rows += column.getKey() + ":" + column.getValue() + "; ";
		}
	    }

	} finally {
	    shutdown();
	}
	return rows;
    }

    public String numeroTiposPokemon() {
	String output = "";

	try (Transaction tx = db.beginTx();
		Result result = db.execute(NoSQL_NUMERO_TIPOS_POKEMON)) {
	    while (result.hasNext()) {
		Map<String, Object> row = result.next();
		for (Entry<String, Object> column : row.entrySet()) {
		    output += column.getValue();
		}
	    }

	} finally {
	    shutdown();
	}
	return output;
    }

    public String pokemonsTipoAgua() {
	String output = "";

	try (Transaction tx = db.beginTx();
		Result result = db.execute(NoSQL_POKEMONS_TIPO_AGUA)) {
	    Iterator<Node> columns = result.columnAs("p");
	    for (Node node : Iterators.asIterable(columns)) {
		output += node.getProperty("nombre") + "\n";
	    }

	} finally {
	    shutdown();
	}
	return output;
    }

    public String pokemonsAgrupadosPorTipo() {
	String output = "";
	boolean salto = false;

	try (Transaction tx = db.beginTx();
		Result result = db
			.execute(NoSQL_POKEMONS_AGRUPADOS_POR_TIPO)) {
	    while (result.hasNext()) {
		Map<String, Object> row = result.next();
		for (Entry<String, Object> column : row.entrySet()) {
		    output += column.getKey() + ": " + column.getValue();
		    if (salto) {
			output += "\n";
			salto = false;
		    } else {
			output += "\t\t";
			salto = true;
		    }
		}
	    }
	} finally {
	    shutdown();
	}
	return output;
    }

    private void shutdown() {
	db.shutdown();
    }

}

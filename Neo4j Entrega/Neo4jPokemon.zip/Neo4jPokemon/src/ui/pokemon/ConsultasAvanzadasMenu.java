package ui.pokemon;

import menu.BaseMenu;
import ui.pokemon.action.CaminoMasCortoAshBulbasur;
import ui.pokemon.action.TiposPokemonAsh;

public class ConsultasAvanzadasMenu extends BaseMenu{
    
    public ConsultasAvanzadasMenu() {
	menuOptions = new Object[][] {
		{ "Pokemaniaco > Consultas > Consultas Avanzadas", null },
	
		{ "Tipos de Pokemon del entrenador Ash", TiposPokemonAsh.class },
		{ "Camino mas corto entre Ash y Bulbasur", CaminoMasCortoAshBulbasur.class }};
    }

}

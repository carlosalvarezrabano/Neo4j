package ui;

import console.Printer;
import menu.BaseMenu;
import ui.pokemon.PokemonMenu;

public class Main {

    private static class MainMenu extends BaseMenu {
	MainMenu() {
	    menuOptions = new Object[][] { { "Pokemaniaco", null },

		    { "Consultas",
			    PokemonMenu.class }, };
	}
    }

    public static void main(String[] args) {
	new Main().run();
    }

    private Main run() {
	try {
	    new MainMenu().execute();

	} catch (RuntimeException rte) {
	    Printer.printRuntimeException(rte);
	}
	return this;
    }

}

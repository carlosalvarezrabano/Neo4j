package ui.pokemon;

import menu.BaseMenu;

public class PokemonMenu extends BaseMenu{
    
    public PokemonMenu() {
	menuOptions = new Object[][] {
		{ "Pokemaniaco > Consultas", null },
	
		{ "Consultas Elementales" , ConsultasElementalesMenu.class },	
		{ "Consultas Intermedias", ConsultasIntermediasMenu.class },
		{ "Consultas Avanzadas", ConsultasAvanzadasMenu.class }};
    }

}

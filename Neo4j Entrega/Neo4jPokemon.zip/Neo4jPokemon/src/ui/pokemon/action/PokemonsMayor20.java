package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class PokemonsMayor20 implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Pokemons cuyo numero es mayor que 20 en orden descendente:");
	Console.println("Nombre_Pokemon   :   Numero_Pokemon"); 
	Console.println(pokemonDb.pokemonsMayor20());
    }
}

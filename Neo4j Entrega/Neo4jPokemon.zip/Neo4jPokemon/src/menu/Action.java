package menu;

public interface Action {
	void execute() throws Exception;
}

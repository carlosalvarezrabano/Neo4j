package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class PokemonsAgrupadosPorTipo implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println(pokemonDb.pokemonsAgrupadosPorTipo());
    }
    
    

}

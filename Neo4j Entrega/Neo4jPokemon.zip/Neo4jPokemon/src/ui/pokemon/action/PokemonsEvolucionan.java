package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class PokemonsEvolucionan implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Pokemons que evolucionan: \n" + pokemonDb.pokemonsEvolucionan());
    }
    
}

package ui.pokemon;

import menu.BaseMenu;
import ui.pokemon.action.NumeroTiposPokemon;
import ui.pokemon.action.PokemonsCazaBichos;
import ui.pokemon.action.PokemonsTipoAgua;
import ui.pokemon.action.TiposGananPlanta;


public class ConsultasElementalesMenu extends BaseMenu{
    
    public ConsultasElementalesMenu() {
	menuOptions = new Object[][] {
		{ "Pokemaniaco > Consultas > Consultas Elementales", null },
	
		{ "Tipos de Pokemon que ganan al tipo planta", TiposGananPlanta.class },
		{ "Nombre de Pokemons del entrenador Caza Bichos", PokemonsCazaBichos.class },
		{ "Pokemons de tipo agua", PokemonsTipoAgua.class },
		{ "Numero de tipos de Pokemon", NumeroTiposPokemon.class }};
    }
}

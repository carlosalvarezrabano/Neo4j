package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class PokemonsTipoAgua implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Pokemons de tipo Agua: \n" + pokemonDb.pokemonsTipoAgua());
    }
    
}

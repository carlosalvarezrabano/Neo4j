package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class PokemonsMayor10Mas1Tipos implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Pokemons cuyo numero sea superior a diez y que tengan mas de un tipo: ");
	Console.println(pokemonDb.pokemonsMayor10Mas1Tipos());
    }

}

package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class CaminoMasCortoAshBulbasur implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Camino mas corto entre Ash y Bulbasur: \n (Los numeros corresponden a los ID de los nodos)");
	Console.println(pokemonDb.caminoMasCortoAshBulbasur());
    }
    
   
    
}

package ui.pokemon.action;

import application.Pokemons;
import menu.Action;
import console.Console;

public class TiposGananPlanta implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Tipos: " + pokemonDb.tiposGananPlanta());
    }

}

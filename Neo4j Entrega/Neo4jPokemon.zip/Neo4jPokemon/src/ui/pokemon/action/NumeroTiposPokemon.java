package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class NumeroTiposPokemon implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Hay un total de " + pokemonDb.numeroTiposPokemon() + " tipos de Pokemon");
    }
    

}

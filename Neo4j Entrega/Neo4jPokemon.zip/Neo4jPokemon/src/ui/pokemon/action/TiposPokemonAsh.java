package ui.pokemon.action;

import application.Pokemons;
import console.Console;
import menu.Action;

public class TiposPokemonAsh implements Action{
    
    @Override
    public void execute() throws Exception {
	
	Pokemons pokemonDb =  new Pokemons();
	Console.println("Tipos de Pokemon del entrenador Ash: \n" + pokemonDb.tiposPokemonAsh());
    }

}

package ui.pokemon;

import menu.BaseMenu;
import ui.pokemon.action.PokemonsAgrupadosPorTipo;
import ui.pokemon.action.PokemonsEvolucionan;
import ui.pokemon.action.PokemonsMayor10Mas1Tipos;
import ui.pokemon.action.PokemonsMayor20;


public class ConsultasIntermediasMenu extends BaseMenu{
    
    public ConsultasIntermediasMenu() {
	menuOptions = new Object[][] {
		{ "Pokemaniaco > Consultas > Consultas Intermedias", null },
	
		{ "Nombre y numero de Pokemons con numero mayor que 20", PokemonsMayor20.class },
		{ "Pokemons con numero superior a 10 y mas de un tipo", PokemonsMayor10Mas1Tipos.class },
		{ "Pokemons que evolucionan", PokemonsEvolucionan.class },
		{ "Pokemons agrupados por tipo", PokemonsAgrupadosPorTipo.class }};
    }

}
